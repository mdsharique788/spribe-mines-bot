// Safe Mines - simple Mines-like game
// Click to reveal, right-click (or long press) to flag.

const boardEl = document.getElementById('board');
const timerEl = document.getElementById('timer');
const minesLeftEl = document.getElementById('minesLeft');
const newBtn = document.getElementById('newBtn');
const sizeSelect = document.getElementById('sizeSelect');
const minesSelect = document.getElementById('minesSelect');

let size = parseInt(sizeSelect.value);
let minesCount = parseInt(minesSelect.value);
let cells = [];
let minePositions = new Set();
let revealedCount = 0;
let flaggedCount = 0;
let timer = null;
let seconds = 0;
let gameOver = false;
let longPressTimer = null;

function newGame() {
  size = parseInt(sizeSelect.value);
  minesCount = parseInt(minesSelect.value);
  boardEl.innerHTML = '';
  cells = [];
  minePositions.clear();
  revealedCount = 0;
  flaggedCount = 0;
  seconds = 0;
  timerEl.textContent = seconds;
  minesLeftEl.textContent = minesCount;
  gameOver = false;
  clearInterval(timer);
  buildGrid(size);
  placeMines();
  calculateNumbers();
}

function buildGrid(n) {
  boardEl.style.gridTemplateColumns = `repeat(${n}, auto)`;
  for (let r=0; r<n; r++) {
    for (let c=0; c<n; c++) {
      const idx = r*n + c;
      const cell = document.createElement('button');
      cell.className = 'cell';
      cell.dataset.idx = idx;
      cell.dataset.r = r;
      cell.dataset.c = c;
      cell.dataset.val = '0';
      cell.setAttribute('aria-label', `Cell ${r+1}-${c+1}`);
      addCellListeners(cell);
      boardEl.appendChild(cell);
      cells.push(cell);
    }
  }
}

function addCellListeners(cell){
  cell.addEventListener('click', onClick);
  cell.addEventListener('contextmenu', onRightClick);
  // simple long-press support for mobile (800ms)
  cell.addEventListener('touchstart', e=>{
    if (gameOver) return;
    longPressTimer = setTimeout(()=> {
      flagCell(e);
    },800);
  }, {passive:true});
  cell.addEventListener('touchend', e=>{
    clearTimeout(longPressTimer);
  });
}

function onClick(e){
  if (gameOver) return;
  const idx = +thisOrTarget(e).dataset.idx;
  if (!timer) startTimer();
  revealCell(idx);
}

function onRightClick(e){
  e.preventDefault();
  if (gameOver) return;
  if (!timer) startTimer();
  flagCell(e);
}

function thisOrTarget(e){
  return e.currentTarget || e.target;
}

function flagCell(e){
  const el = thisOrTarget(e);
  const idx = +el.dataset.idx;
  if (cells[idx].classList.contains('revealed')) return;
  if (cells[idx].classList.contains('flag')) {
    cells[idx].classList.remove('flag');
    flaggedCount--;
  } else {
    cells[idx].classList.add('flag');
    flaggedCount++;
  }
  minesLeftEl.textContent = Math.max(0, minesCount - flaggedCount);
  checkWin();
}

function placeMines(){
  const total = size*size;
  while (minePositions.size < minesCount) {
    const pos = Math.floor(Math.random()*total);
    minePositions.add(pos);
    cells[pos].dataset.val = 'M';
  }
}

function calculateNumbers(){
  const n=size;
  for (let r=0;r<n;r++){
    for (let c=0;c<n;c++){
      const idx = r*n + c;
      if (cells[idx].dataset.val === 'M') {
        cells[idx].classList.add('mine'); // hidden style only for later reveal
        continue;
      }
      let count = 0;
      for (let dr=-1; dr<=1; dr++){
        for (let dc=-1; dc<=1; dc++){
          if (dr===0 && dc===0) continue;
          const rr = r+dr, cc = c+dc;
          if (rr<0||cc<0||rr>=n||cc>=n) continue;
          const neighborIdx = rr*n+cc;
          if (cells[neighborIdx].dataset.val === 'M') count++;
        }
      }
      cells[idx].dataset.val = String(count);
    }
  }
}

function revealCell(idx){
  const el = cells[idx];
  if (!el || el.classList.contains('revealed') || el.classList.contains('flag')) return;
  el.classList.add('revealed');
  const val = el.dataset.val;
  if (val === 'M') {
    // reveal mines and end
    el.classList.add('mine');
    loseGame();
    return;
  }
  revealedCount++;
  if (val !== '0') {
    el.textContent = val;
    el.style.color = colorForNumber(+val);
  } else {
    // flood fill neighbors
    el.textContent = '';
    const n=size;
    const r = +el.dataset.r, c = +el.dataset.c;
    for (let dr=-1; dr<=1; dr++){
      for (let dc=-1; dc<=1; dc++){
        if (dr===0 && dc===0) continue;
        const rr=r+dr, cc=c+dc;
        if (rr<0||cc<0||rr>=n||cc>=n) continue;
        revealCell(rr*n+cc);
      }
    }
  }
  checkWin();
}

function colorForNumber(num){
  switch(num){
    case 1: return '#1e40af';
    case 2: return '#0f766e';
    case 3: return '#b91c1c';
    case 4: return '#7c2d12';
    case 5: return '#6b21a8';
    default: return '#0b1220';
  }
}

function loseGame(){
  gameOver = true;
  clearInterval(timer);
  // reveal all mines
  minePositions.forEach(i=>{
    const c = cells[i];
    if (!c.classList.contains('revealed')) {
      c.classList.add('revealed','mine');
      c.textContent = '💣';
    }
  });
  setTimeout(()=> alert('Boom! You hit a mine — Game over.'), 100);
}

function checkWin(){
  const total = size*size;
  if (revealedCount + minePositions.size === total) {
    gameOver = true;
    clearInterval(timer);
    setTimeout(()=> alert(`Congratulations! You cleared the board in ${seconds}s.`), 80);
    // optionally reveal flags
  }
}

function startTimer(){
  timer = setInterval(()=>{
    seconds++;
    timerEl.textContent = seconds;
  },1000);
}

newBtn.addEventListener('click', newGame);
sizeSelect.addEventListener('change', ()=> {
  // adjust default mines when size changes
  const s = parseInt(sizeSelect.value);
  const area = s*s;
  // scale mines proportionally
  minesSelect.value = Math.max(5, Math.round(area*0.15));
});
minesSelect.addEventListener('change', ()=>{ /* nothing */});

newGame();
